module.exports = { // adapted from: https://git.io/vodU0
  'Los estudiantes login falied': function(browser) {
    browser
      .url('https://losestudiantes.co/')
      .click('.botonCerrar')
      .waitForElementVisible('.botonIngresar', 4000)
      .click('.botonIngresar')
      .setValue('.cajaLogIn input[name="correo"]', 'wrongemail@example.com')
      .setValue('.cajaLogIn input[name="password"]', '1234')
      .click('.cajaLogIn .logInButton')
      .waitForElementVisible('.aviso.alert.alert-danger', 4000)
      .assert.containsText('.aviso.alert.alert-danger', 'El correo y la contraseña que ingresaste no figuran')
      .end();
  }
};

module.exports = { // adapted from: https://git.io/vodU0
  'Los estudiantes crear cuenta': function(browser) {
    browser
      .url('https://losestudiantes.co/')
      .click('.botonCerrar')
      .waitForElementVisible('.botonIngresar', 4000)
      .click('.botonIngresar')
      .setValue('.cajaSignUp input[name="nombre"]', 'Vivi')
      .setValue('.cajaSignUp input[name="apellido"]', 'Mendoza')
      .setValue('.cajaSignUp input[name="correo"]', 'Mendoza@gmail.com')
      .setValue('select[name="idUniversidad"]','Universidad de los Andes')
      .click('input[type="checkbox"]')
      .setValue('select[name="idPrograma"]','Maestría en Ingeniería de Software')
      .setValue('.cajaSignUp input[name="password"]', '12345678')
      .click('input[name="acepta"]')
      .click('button[type="submit"]')
      .end();
  }
};

module.exports = { // adapted from: https://git.io/vodU0
  'Los estudiantes cuenta existente': function(browser) {
    browser
      .url('https://losestudiantes.co/')
      .click('.botonCerrar')
      .waitForElementVisible('.botonIngresar', 4000)
      .click('.botonIngresar')
      .setValue('.cajaSignUp input[name="nombre"]', 'Vivi')
      .setValue('.cajaSignUp input[name="apellido"]', 'Mendoza')
      .setValue('.cajaSignUp input[name="correo"]', 'Mendoza@gmail.com')
      .setValue('select[name="idUniversidad"]','Universidad de los Andes')
      .click('input[type="checkbox"]')
      .setValue('select[name="idPrograma"]','Maestría en Ingeniería de Software')
      .setValue('.cajaSignUp input[name="password"]', '12345678')
      .click('input[name="acepta"]')
      .click('button[type="submit"]')
      .click('button[type="button"]')
      .end();
  }
};

module.exports = { // adapted from: https://git.io/vodU0
  'Los estudiantes Dirigirse a pagina de profesor': function(browser) {
    browser
      .url('https://losestudiantes.co/')
      .click('.botonCerrar')

      .setValue('.splash select[id="sample_select"]', 'Química')
      .waitForElementVisible('.profesor', 20000)
      .click('.profesor a')
      .end();
  }
};
